/**
 * Kayak Java Engineering Intern Screening
 *
 * @author Ankit Sahu
 */
package exercise1.robot.enums;

public enum FacingDirection {
    NORTH, SOUTH, EAST, WEST
}
