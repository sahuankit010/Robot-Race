/**
 * Kayak Java Engineering Intern Screening
 *
 * @author Ankit Sahu
 *
 *
 */
package com.exercise.tests;

import solutions.Exercise3;

/*
Test for Exercise 3 is not completed, although I have created various robotRace objects in solutions.Exercise3. Uncomment to test the code.
 */

public class Exercise3Test {

    public static void main(String[] args) {
        Exercise3.main(null);
    }
}
